from slack_sdk.rtm_v2 import RTMClient

__all__ = [
    "RTMClient",
]
